import sys

"""
sys.argv[1] #命令运行参数 list

sys.exit() #退出程序 正常退出时exit(0)

sys.version #获取python解释程序的版本信息
"""
"""
sys.path #返回模块的搜索值

sys.platform  #返回操作系统平台名称

sys.stdout.write('please:')# 
"""